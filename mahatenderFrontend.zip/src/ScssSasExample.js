import './ScssSasExample.scss'
const ScssSasExample=()=>{
return(
    <>
    <div className='container'>
        <h1>Welcome to React with SCSS</h1>
        <p>This is an exapmle of SCSS in a React project</p>
    </div>
    </>
)
 }
 export default ScssSasExample;