
import React, { useEffect, useState } from 'react';
import AddMeter from '../components/modals/AddMeter';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useDispatch, useSelector } from 'react-redux';
import { addMeter, fetchMeters, deleteMeter, editMeter } from '../store/actions/meterActions';
import { DataGrid } from '@mui/x-data-grid';
import { Typography, CircularProgress,TextField} from '@mui/material';
import './Rolemaster.css';
import './TenderList.css';
import { styled } from '@mui/material/styles';
import { baseUrl,fileBaseUrl } from '../config/config';
import * as XLSX from 'xlsx';
import { toast } from "react-toastify";
import DownloadIcon from '@mui/icons-material/Download';

const columns = (handleDeleteMeter, handleEditMeter) => [
  { field: 'id', headerName: 'ID', width: 40 },
  { field: 'tenderId', headerName: 'Tender ID', width: 120 },
   { field: 'tenderType', headerName: 'Tender Type', width: 120 },
    { field: 'tenderCategory', headerName: 'Category', width: 120 },
     { field: 'formOfContract', headerName: 'Contract Form', width: 140 },
       { field: 'noOfCovers', headerName: 'No. of Covers', width: 120 },
        { field: 'coverType', headerName: 'Cover Type', width: 120 },
         { field: 'tenderFee', headerName: 'Tender Fee', width: 100 },
         { field: 'emdAmount', headerName: 'EMD Amount', width: 120 },
           { field: 'tenderTitle', headerName: 'Tender Title', width: 200 },
           { field: 'workDescription', headerName: 'Work Description', width: 200 },
           { field: 'tenderValueInRs', headerName: 'Tender Value In Rs.', width: 140 },
            { field: 'productCategory', headerName: 'Product Category', width: 160 },
            { field: 'bidValidityDays', headerName: 'Bid Validity', width: 130 },
             { field: 'periodOfWorkDays', headerName: 'Work Period (Days)', width: 160 },
               { field: 'preBidMeetingPlace', headerName: 'Pre Bid Place', width: 160 },
                { field: 'preBidMeetingAddress', headerName: 'Pre Bid Address', width: 200 },
                 { field: 'preBidMeetingDate', headerName: 'Pre Bid Meeting Date', width: 200 },
                  { field: 'criticalDates', headerName: 'Critical Dates', width: 200 },
                  { field: 'publishedDate', headerName: 'Published Date', width: 200 },
                   { field: 'documentDownloadSaleEndDate', headerName: ' Document Download Sale End Date', width: 200 },
                 { field: 'bidSubmissionStartDate', headerName: 'Bid Submission Start Date', width: 200 },
  { field: 'bidSubmissionEndDate', headerName: 'Bid Submission End Date', width: 200 },
   {
  field: 'tendersDocuments',
  headerName: 'Tender Documents',
  width: 200,
  renderCell: (params) => {
    const docs = params.row?.tendersDocuments || [];
    if (!docs.length) return '-';

    return (
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {docs.map((doc, index) => (
          <a
            key={index}
            href={`${fileBaseUrl}/${doc.filePath.replace(/\\/g, '/')}`}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: 'blue', textDecoration: 'underline', marginBottom: '4px' }}
          >
            {doc.originalName || `Document ${index + 1}`}
          </a>
        ))}
      </div>
    );
  }
},

  {
  field: 'technicalDocumentOfBidder',
  headerName: 'Technical Document Of Bidder',
  width: 200,
  renderCell: (params) => {
    const docs = params.row?.technicalDocumentOfBidder || [];
    if (!docs.length) return '-';

    return (
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {docs.map((doc, index) => (
          <a
            key={index}
            href={`${fileBaseUrl}/${doc.filePath.replace(/\\/g, '/')}`}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: 'blue', textDecoration: 'underline', marginBottom: '4px' }}
          >
            {doc.originalName || `Document ${index + 1}`}
          </a>
        ))}
      </div>
    );
  }
},

{
  field: 'financialDocumentOfBidder',
  headerName: 'Financial Document Of Bidder',
  width: 200,
  renderCell: (params) => {
    const docs = params.row?.financialDocumentOfBidder || [];
    if (!docs.length) return '-';

    return (
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {docs.map((doc, index) => (
          <a
            key={index}
            href={`${fileBaseUrl}/${doc.filePath.replace(/\\/g, '/')}`}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: 'blue', textDecoration: 'underline', marginBottom: '4px' }}
          >
            {doc.originalName || `Document ${index + 1}`}
          </a>
        ))}
      </div>
    );
  }
},

{ field: 'AOC', headerName: 'AOC', width: 120 },


  { field: 'documentType', headerName: 'Document Type', width: 200 },
{ field: 'tenderInvitingAuthority', headerName: 'Tender Inviting Authority', width: 120 },
  { field: 'tname', headerName: 'Name', width: 120 },
 { field: 'address', headerName: 'Address', width: 120 },
 { field: 'estimateCost', headerName: 'Estimate Cost', width: 120 },
 { field: 'nameOfBidder', headerName: 'Name Of Bidder', width: 120 },
{ field: 'subCategory', headerName: 'Sub Category', width: 160 },
{ field: 'organisationChain', headerName: 'Organisation Chain', width: 120 },



  { field: 'tenderRefNo', headerName: 'Ref No.', width: 120 },
 
  { field: 'tenderStatus', headerName: 'Status', width: 120 },
  { field: 'bidNumber', headerName: 'Bid Number', width: 120 },
 
  
  { field: 'awardedCurrency', headerName: 'Awarded Currency', width: 100 },
  { field: 'awardedValue', headerName: 'Awarded Value', width: 140 },
  {
  field: 'documentLink',
  headerName: 'Document Link',
  width: 160,
  renderCell: (params) => (
    params.value ? (
      <a href={params.value} target="_blank" rel="noopener noreferrer">
        View
      </a>
    ) : (
      <span style={{ color: '#999' }}>No Link</span>
    )
  ),
},
 
  
  {
    field: 'actions',
    headerName: 'Actions',
    width: 130,
    renderCell: (params) => (
      <>
        <IconButton sx={{ color: '#FFA534' }} onClick={() => handleDeleteMeter(params.row._id)}>
          <DeleteIcon />
        </IconButton>
        <IconButton sx={{ color: '#23CCEF' }} onClick={() => handleEditMeter(params.row)}>
          <EditIcon />
        </IconButton>
      </>
    ),
  },
];

const MeterComponent = () => {
  const dispatch = useDispatch();
  const { meters, loading, error } = useSelector((state) => state.meters);
  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);

  const [meterOpen, setMeterOpen] = useState(false);
  const [currentMeter, setCurrentMeter] = useState(null);
const [isImporting, setIsImporting] = useState(false); 
const [tenderIdN, setTenderIdN] = useState('');
  useEffect(() => {
    dispatch(fetchMeters());
  }, [dispatch]);

  const handleAddMeterOpen = () => {
    setCurrentMeter(null);
    setMeterOpen(true);
  };

  const handleAddMeterClose = () => {
    setMeterOpen(false);
  };

  const handleAddMeter = (meterData) => {
    dispatch(addMeter(meterData));
    handleAddMeterClose();
  };

  const handleEditMeter = (meter) => {
    setCurrentMeter(meter);
    setMeterOpen(true);
  };

  const handleDeleteMeter = (meterId) => {
    dispatch(deleteMeter(meterId));
  };

  const deleteAllTenders = () => {
      fetch(`${baseUrl}/deleteAllTenders`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
      })
        .then((response) => response.json())
        .then((data) => {
          console.log('All tenders deleted:', data);
          alert(data.message); 
        })
        .catch((error) => {
          console.error('Error deleting tenders:', error);
          alert('Error deleting tenders');
        });
    };
    

  // const importExcel = async (event) => {
  //   const file = event.target.files[0]; 
  //   if (!file) return;
  //   setIsImporting(true);
  
  //   const reader = new FileReader();
  //   reader.onload = async (e) => {
  //     const data = new Uint8Array(e.target.result);
  //     const workbook = XLSX.read(data, { type: 'array' });
  
  //     const sheetName = workbook.SheetNames[0];
  //     const sheet = workbook.Sheets[sheetName];
  
  //     const jsonData = XLSX.utils.sheet_to_json(sheet);
  
      
  //     const cleanedData = jsonData.map(item => ({
  //       tenderId: item.tenderId || '',
  //        tenderType: item.tenderType || '',
  //         tenderCategory: item.tenderCategory || '',
  //         formOfContract:item.formOfContract || '',
  //          noOfCovers:item.noOfCovers || '',
  //           coverType:item.coverType || '',
  //             tenderFee:item.tenderFee || '',
  //             emdAmount:item.emdAmount || '',
  //             tenderTitle: item.tenderTitle || '',
  //             workDescription:item.workDescription || '',
  //             tenderValueInRs:item.tenderValueInRs || '',
  //             productCategory:item.productCategory || '',
  //            bidValidityDays:item.bidValidityDays || '',
  //           periodOfWorkDays:item.periodOfWorkDays || '',
  //          preBidMeetingPlace:item.preBidMeetingPlace || '',
  //          preBidMeetingAddress:item.preBidMeetingPlace || '',
  //         preBidMeetingDate:item.preBidMeetingDate || '',
  //         criticalDates:item.criticalDates || '',
  //          publishedDate:item.publishedDate || '',
  //           documentDownloadSaleEndDate:item.documentDownloadSaleEndDate || '',
  //           bidSubmissionStartDate:item.bidSubmissionStartDate || '',
  //           bidSubmissionEndDate:item.bidSubmissionEndDate || '',
  //           tendersDocuments:item.tendersDocuments || '',
  //           documentType:item.documentType || '',
  //           tenderInvitingAuthority:item.tenderInvitingAuthority || '',
  //           tname:item.tname || '',
  //           address:item.address || '',
  //           estimateCost:item.estimateCost || '',
  //           nameOfBidder:item.nameOfBidder || '',
  //           technicalDocumentOfBidder:item.technicalDocumentOfBidder || '',
  //           financialDocumentOfBidder:item.financialDocumentOfBidder || '',
  //           organisationChain:item.organisationChain || '',
  //        AOC:item.AOC || '',
  //        subCAtegory:item.subCAtegory || '',

    
        


  //     }));
  
  //     console.log("Total Records:", cleanedData.length);
  
      
  //     const chunkSize = 100;
  //     for (let i = 0; i < cleanedData.length; i += chunkSize) {
  //       const chunk = cleanedData.slice(i, i + chunkSize);
  
  //       try {
  //         const response = await fetch(`${baseUrl}/import-excel`, {
  //           method: 'POST',
  //           headers: { 'Content-Type': 'application/json' },
  //           body: JSON.stringify(chunk),
  //         });
  
  //         const result = await response.json();
  //         console.log(`Batch ${i / chunkSize + 1} imported successfully:`, result);
  //       } catch (error) {
  //         console.error(`Error importing batch ${i / chunkSize + 1}:`, error);
  //       }
  //     }
  //     setIsImporting(false);
  //     // dispatch(fetchConsumers());
  //     toast.success("Consumer data has been successfully imported.");
  //   };
  
  //   reader.readAsArrayBuffer(file);
  // };


//   const importExcel = async (event) => {
//   const file = event.target.files[0];
//   if (!file) return;

//   setIsImporting(true);

//   const reader = new FileReader();
//   reader.onload = async (e) => {
//     const data = new Uint8Array(e.target.result);
//     const workbook = XLSX.read(data, { type: 'array' });
//     const sheet = workbook.Sheets[workbook.SheetNames[0]];
//     const jsonData = XLSX.utils.sheet_to_json(sheet);

//     const cleanedData = jsonData.map(item => ({
//       tenderId: item.tenderId || '',
//       tenderType: item.tenderType || '',
//       tenderCategory: item.tenderCategory || '',
//       formOfContract: item.formOfContract || '',
//       noOfCovers: item.noOfCovers || '',
//       coverType: item.coverType || '',
//       tenderFee: Number(item.tenderFee) || 0,
//       emdAmount: Number(item.emdAmount) || 0,
//       tenderTitle: item.tenderTitle || '',
//       workDescription: item.workDescription || '',
//       tenderValueInRs: item.tenderValueInRs || '',
//       productCategory: item.productCategory || '',
//       bidValidityDays: item.bidValidityDays || '',
//       periodOfWorkDays: item.periodOfWorkDays || '',
//       preBidMeetingPlace: item.preBidMeetingPlace || '',
//       preBidMeetingAddress: item.preBidMeetingAddress || '',
//       preBidMeetingDate: item.preBidMeetingDate || '',
//       criticalDates: item.criticalDates || '',
//       publishedDate: item.publishedDate || '',
//       documentDownloadSaleEndDate: item.documentDownloadSaleEndDate || '',
//       bidSubmissionStartDate: item.bidSubmissionStartDate || '',
//       bidSubmissionEndDate: item.bidSubmissionEndDate || '',
//  tendersDocuments: item.tendersDocuments || [],
// technicalDocumentOfBidder: item.technicalDocumentOfBidder || [],
//       financialDocumentOfBidder: item.financialDocumentOfBidder || [],
//   AOC: item.AOC || '',
//       documentType: item.documentType || '',

//       tenderInvitingAuthority: item.tenderInvitingAuthority || '',
//       tname: item.tname || '',
//       address: item.address || '',
//       estimateCost: item.estimateCost || '',
//       nameOfBidder: item.nameOfBidder || '',
//       subCategory: item.subCategory || '',
//       organisationChain: item.organisationChain || '',
    
      
//       tenderRefNo: item.tenderRefNo || '',
//       tenderStatus: item.tenderStatus || '',
//       bidNumber: Number(item.bidNumber) || 0,
//       awardedCurrency: item.awardedCurrency || '',
//       awardedValue: item.awardedValue || '',
//       documentLink: item.documentLink || '',

//       // Optional fields (files)
     
      
//     }));

//     const chunkSize = 100;
//     for (let i = 0; i < cleanedData.length; i += chunkSize) {
//       const chunk = cleanedData.slice(i, i + chunkSize);

//       try {
//         const response = await fetch(`${baseUrl}/import-excel`, {
//           method: 'POST',
//           headers: { 'Content-Type': 'application/json' },
//           body: JSON.stringify(chunk),
//         });

//         const result = await response.json();
//         console.log(`Batch ${i / chunkSize + 1} imported:`, result);
//       } catch (error) {
//         console.error(`Batch ${i / chunkSize + 1} failed:`, error);
//       }
//     }

//     toast.success("Tender data has been successfully imported.");
//     setIsImporting(false);
//   };

//   reader.readAsArrayBuffer(file);
// };






const convertExcelDate = (excelDate) => {
  if (!excelDate || isNaN(excelDate)) return 'NA';

  const date = new Date(Math.round((excelDate - 25569) * 86400 * 1000));
  const pad = (n) => (n < 10 ? '0' + n : n);

  return `${pad(date.getDate())}-${pad(date.getMonth() + 1)}-${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
};

const importExcel = async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  setIsImporting(true);

  const reader = new FileReader();
  reader.onload = async (e) => {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const jsonData = XLSX.utils.sheet_to_json(sheet);

    const cleanedData = jsonData.map(item => ({
      tenderId: item.tenderId || '',
      tenderType: item.tenderType || '',
      tenderCategory: item.tenderCategory || '',
      formOfContract: item.formOfContract || '',
      noOfCovers: item.noOfCovers || '',
      coverType: item.coverType || '',
      tenderFee: Number(item.tenderFee) || 0,
      emdAmount: Number(item.emdAmount) || 0,
      tenderTitle: item.tenderTitle || '',
      workDescription: item.workDescription || '',
      tenderValueInRs: item.tenderValueInRs || '',
      productCategory: item.productCategory || '',
      bidValidityDays: item.bidValidityDays || '',
      periodOfWorkDays: item.periodOfWorkDays || '',
      preBidMeetingPlace: item.preBidMeetingPlace || '',
      preBidMeetingAddress: item.preBidMeetingAddress || '',
      preBidMeetingDate: convertExcelDate(item.preBidMeetingDate),
      criticalDates: convertExcelDate(item.criticalDates),
      publishedDate: convertExcelDate(item.publishedDate),
      documentDownloadSaleEndDate: convertExcelDate(item.documentDownloadSaleEndDate),
      bidSubmissionStartDate: convertExcelDate(item.bidSubmissionStartDate),
      bidSubmissionEndDate: convertExcelDate(item.bidSubmissionEndDate),
      tendersDocuments: item.tendersDocuments || [],
      technicalDocumentOfBidder: item.technicalDocumentOfBidder || [],
      financialDocumentOfBidder: item.financialDocumentOfBidder || [],
      AOC: item.AOC || '',
      documentType: item.documentType || '',
      tenderInvitingAuthority: item.tenderInvitingAuthority || '',
      tname: item.tname || '',
      address: item.address || '',
      estimateCost: item.estimateCost || '',
      nameOfBidder: item.nameOfBidder || '',
      subCategory: item.subCategory || '',
      organisationChain: item.organisationChain || '',
      tenderRefNo: item.tenderRefNo || '',
      tenderStatus: item.tenderStatus || '',
      bidNumber: Number(item.bidNumber) || 0,
      awardedCurrency: item.awardedCurrency || '',
      awardedValue: item.awardedValue || '',
      documentLink: item.documentLink || '',
    }));

    const chunkSize = 100;
    for (let i = 0; i < cleanedData.length; i += chunkSize) {
      const chunk = cleanedData.slice(i, i + chunkSize);

      try {
        const response = await fetch(`${baseUrl}/import-excel`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(chunk),
        });

        const result = await response.json();
        console.log(`Batch ${i / chunkSize + 1} imported:`, result);
      } catch (error) {
        console.error(`Batch ${i / chunkSize + 1} failed:`, error);
      }
    }

    toast.success("Tender data has been successfully imported.");
    setIsImporting(false);
  };

  reader.readAsArrayBuffer(file);
};



 const handleChange = (event) => {
    setTenderIdN(event.target.value);
  };

    
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return <p>Error: {error}</p>;
  }

  const rows = meters.filter(meter => !tenderIdN || meter?.tenderId === tenderIdN) .map((meter, index) => ({
    id: index + 1,
    // _id: meter?._id || '-',
    tenderId: meter?.tenderId || '-',
    tenderType: meter?.tenderType || '-',
    tenderCategory: meter?.tenderCategory || '-',
    formOfContract: meter?.formOfContract || '-',
    noOfCovers: meter?.noOfCovers || '-',
    coverType: meter?.coverType || '-',
    tenderFee: meter?.tenderFee || '-',
    emdAmount: meter?.emdAmount || '-',
  tenderTitle: meter?.tenderTitle || '-',
workDescription:meter?.workDescription ||'-',
tenderValueInRs: meter?.tenderValueInRs || '-',
 productCategory: meter?.productCategory || '-',
 bidValidityDays: meter?.bidValidityDays || '-',
 periodOfWorkDays: meter?.periodOfWorkDays || '-',
 preBidMeetingPlace: meter?.preBidMeetingPlace || '-',
  preBidMeetingAddress: meter?.preBidMeetingAddress || '-',
 preBidMeetingDate: meter?.preBidMeetingDate || '-',
 criticalDates: meter?.criticalDates || '-',
    publishedDate: meter?. publishedDate || '-',
documentDownloadSaleEndDate: meter?.documentDownloadSaleEndDate || '-',
     bidSubmissionStartDate: meter?.bidSubmissionStartDate || '-',
     bidSubmissionEndDate: meter?.bidSubmissionEndDate || '-',
 tendersDocuments: meter?.tendersDocuments || '-',
    technicalDocumentOfBidder: meter?.technicalDocumentOfBidder || '-',
financialDocumentOfBidder: meter?.financialDocumentOfBidder|| '-',
       AOC: meter?.AOC ||'-', 
 documentType: meter?.documentType || '-',
      tenderInvitingAuthority:meter?.tenderInvitingAuthority || '-',
 tname:meter?.tname || '-',
        address:meter?.address || '-',
estimateCost:meter?.estimateCost || '-',
nameOfBidder:meter?.nameOfBidder || '-',
 subCategory: meter?.subCategory || '-',
  organisationChain: meter?.organisationChain || '-',
    tenderRefNo: meter?.tenderRefNo || '-',
  
    tenderStatus: meter?.tenderStatus || '-',
    bidNumber: meter?.bidNumber || '-',
    awardedCurrency: meter?.awardedCurrency || '-',
    awardedValue: meter?.awardedValue || '-',
    documentLink: meter?.documentLink || '-',
  }));

  const gridStyle = {
    height: 'auto',
    width: isSidebarOpen ? '80%' : '90%',
    marginLeft: isSidebarOpen ? '19%' : '7%',
    transition: 'margin-left 0.3s',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: '30px 0px',
    paddingLeft: '10px',
  };

  const innerDivStyle = {
    border: '1px solid #F7F7F8',
    width: '99%',
    padding: '30px 10px',
  };

  const rowColors = ['#F7F9FB', 'white'];
  const StyledDataGrid = styled(DataGrid)(({ theme }) => ({
    '& .MuiDataGrid-cell': {
      padding: theme.spacing(1),
    },
    '& .MuiDataGrid-row': {
      '&:nth-of-type(odd)': {
        backgroundColor: rowColors[0],
      },
      '&:nth-of-type(even)': {
        backgroundColor: rowColors[1],
      },
    },
  }));

  return (
    <div style={gridStyle}>
      <Box sx={innerDivStyle}>
        <Box sx={{ width: '100%', display: 'flex', justifyContent: 'space-between', mb: 2 }}>
          <Typography style={{ paddingLeft: '20px', color: '#0d2136' }} className='title-2'>
            Tender MASTER
          </Typography>

        <Box sx={{display:'flex',width:'54%',justifyContent:'space-between',alignItems:'center'}}>
           {/* <Button
          size="small"
            component="label"
            sx={{
              color: '#23CCEF',
              border: '0.1px solid #23CCEF',
              cursor: 'pointer',
              textTransform: 'none',
              display: 'flex',
              justifyContent: 'space-between',
              width: 'auto',
            }}
            onClick={deleteAllTenders}
          >
            <AddIcon />
            <Typography>Delete All</Typography>
          </Button>  */}

          <TextField
              id="tenderId"
              name="tenderId"
              label="Search Tender ID"
              size="small"
              value={tenderIdN}
              onChange={
                handleChange}
              variant="outlined"
              InputProps={{
                sx: {
                  // height: '40px',
                  mb:1
                },
              }}
              InputLabelProps={{
                sx: {
                  color: 'gray',
                  transform: 'translate(14px, 8px)',
                  fontSize:'17px',
                  transform: 'translate(14px, 8px)',
                  '&.MuiInputLabel-shrink': {
          transform: 'translate(14px, -8px) scale(0.75)', 
          },
                },
               
              }}
              sx={{
                width: {
                  xl: '40%',
                  lg: '40%',
                  md: '30%',
                  sm: '40%',
                  xs: '100%'
                }, 
                mt:{
                  sm:1
                }
                
              }}
            />
          
  <Button
            component="label"
          sx={{
              backgroundColor:'#fff',
              color: '#23CCEF',
              border: '0.1px solid #23CCEF',
              cursor: 'pointer',
              textTransform: 'uppercase',
              display: 'flex',
              justifyContent: 'space-between',
              width: 'auto',
              ml:{
                xs:2,
                sm:5,
                md:0,
                lg:0,
                xl:0
                    },
                    mt:{
                      xs:1,
                      sm:0,
                      md:0,
                      lg:0,
                      xl:0

                    },
                     '&:hover': {
               backgroundColor: '#23CCEF',
               color: '#fff',
              },
            }}
          >
            <AddIcon sx={{ marginLeft: '2px' }} />
            <Typography>Import Excel</Typography>
            <input type="file" hidden onChange={importExcel} accept=".xlsx, .xls" />
          </Button>
          <Button
          className="tenderButton"
            sx={{
              backgroundColor:'#fff',
              color: '#23CCEF',
              border: '0.1px solid #23CCEF',
              cursor: 'pointer',
              textTransform: 'uppercase',
              fontWeight:'bold',
              display: 'flex',
              justifyContent: 'space-between',
              width: 'auto',
              ml:{
                xs:2,
                sm:5,
                md:0,
                lg:0,
                xl:0
                    },
                    mt:{
                      xs:1,
                      sm:0,
                      md:0,
                      lg:0,
                      xl:0

                    },
                     '&:hover': {
               backgroundColor: '#23CCEF',
               color: '#fff',
              },
            }}
           
            onClick={handleAddMeterOpen}
          >
            <AddIcon sx={{ marginLeft: '2px' }} />
            <Typography>Add Tender</Typography>
          </Button>
        </Box>
        
        </Box>
        <StyledDataGrid
          autoHeight
          rows={rows}
          columns={columns(handleDeleteMeter, handleEditMeter)}
          initialState={{
            pagination: { paginationModel: { page: 0, pageSize: 5 } },
          }}
          pageSizeOptions={[5,10,50,100]}
          checkboxSelection
        />
        <AddMeter
          open={meterOpen}
          handleClose={handleAddMeterClose}
          handleAddMeter={handleAddMeter}
          currentMeter={currentMeter}
          editMeter={(meterId, meterData) => {
            dispatch(editMeter(meterId, meterData));
            dispatch(fetchMeters());
          }}
        />
      </Box>
    </div>
  );
};

export default MeterComponent;


