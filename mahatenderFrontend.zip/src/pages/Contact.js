

import React from 'react';
import { Box } from '@mui/material';
const Contact = () => {
  return (
  <>
      <Box sx={{ display: 'flex' }}>
    
<h1 style={{marginTop:"100px"}}>Contact</h1>

      </Box>
  
  </>

  )
}

export default Contact