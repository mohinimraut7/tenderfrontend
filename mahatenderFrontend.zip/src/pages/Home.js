
import React, { useEffect,useState } from 'react';
import { useTheme } from '@mui/material/styles';
import { useMediaQuery } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers } from '../store/actions/userActions';
import {fetchBills} from '../store/actions/billActions';
import { fetchRoles } from '../store/actions/roleActions';
import { fetchMeters } from '../store/actions/meterActions';
import { fetchConsumers } from '../store/actions/consumerActions';
import { getMasters } from '../store/actions/masterActions';
import InfoCard from '../components/cards/InfoCard';
import { CircularProgress, Box } from '@mui/material';
import './Home.css';
import Person2OutlinedIcon from '@mui/icons-material/Person2Outlined';
import AverageMetersCurrentMonth from '../components/table/AverageMetersCurrentMonth';
import FaultyMetersCurrentMonth from '../components/table/FaultyMetersCurrentMonth';
import UpcomingDueBillCurrentMonth from '../components/table/UpcomingDueBillCurrenthMonth';
import PaidBillpreviousTwoMonthBefore from '../components/table/PaidBillpreviousTwoMonthBefore';
import FaultyMetersBeforeTwoMonth from '../components/table/FaultyMetersBeforeTwoMonth';
import OverdueBillsTable from '../components/table/OverdueBillsTable';
const Home = () => {
  const dispatch = useDispatch();
  const isSidebarOpen = useSelector((state) => state.sidebar.isOpen);
    const user = useSelector(state => state.auth.user);
  const { meters, loading: loadingMeters, error: errorUsers } = useSelector((state) => state.meters);
  const { loading: loadingRoles, error: errorRoles } = useSelector((state) => state.roles);
  const [showCMonthAvgTable, setShowCMonthAvgTable] = useState(false);
  const [showCMonthUDueBill, setshowCMonthUDueBill] = useState(false);
  const [showOverdueBill, setShowOverdueBill] = useState(false);
const [showPTwoMonthBeforePaidTable,setShowPTwoMonthBeforePaidTable]=useState(false);
  const [showCMonthFaultyTable, setShowCMonthFaultyTable] = useState(false);
  const [showBeforeTwoMonthFaultyTable, setShowBeforeTwoMonthFaultyTable] = useState(false);
const currentDate = new Date();
const prevDate = new Date(currentDate);
prevDate.setMonth(prevDate.getMonth() - 1);
const prevDateTwo = new Date(currentDate);
prevDateTwo.setMonth(prevDateTwo.getMonth() - 2);
  const theme = useTheme();
  const isXs = useMediaQuery(theme.breakpoints.down('xs'));
  const isSm = useMediaQuery(theme.breakpoints.down('sm'));
  const isMd = useMediaQuery(theme.breakpoints.down('md'));
  const isLg = useMediaQuery(theme.breakpoints.down('lg'));
  const isXl = useMediaQuery(theme.breakpoints.down('xl'));
  useEffect(() => {
    dispatch(fetchUsers());
    dispatch(fetchBills());
    dispatch(getMasters());
    dispatch(fetchRoles());
    dispatch(fetchMeters());
    dispatch(fetchConsumers());
    document.body.classList.add('home-body');
    return () => {
     
      document.body.classList.remove('home-body');
    };

  }, [dispatch]);

  if ( loadingRoles) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <CircularProgress />
      </Box>
    );
  }

  if (errorUsers) {
    return <p>Error loading users: {errorUsers}</p>;
  }

  if (errorRoles) {
    return <p>Error loading roles: {errorRoles}</p>;
  }
  const gridStyle = {
    width: '100%',
    
    width: isSm || isXs ? '80%' : isSidebarOpen ? '80%' : '95%',
  
  marginLeft: isSm || isXs ? '60px' : isSidebarOpen ? '20%' : '6%',
 
  display: 'flex',
  justifyContent: 'center',
  alignContent: 'center',
  alignItems:'center'
  };
  
  return (
    <div style={gridStyle} className="containerhome">
     <div className="info-card-container" sx={{width: isSm || isXs? '100%' : '30%'}}
     >
 

{(user?.role === 'Super Admin' || user?.role === 'Admin' || user?.role === 'Executive Engineer' || (user?.role === 'Junior Engineer' && user?.ward === 'Head Office')) &&
 (showCMonthAvgTable || showCMonthFaultyTable || showCMonthUDueBill) && (
  <Box sx={{
    display: 'flex',
    flexDirection: {
      xl: 'row',
      lg: 'row',
      md: 'row',
      sm: 'column',
      xs: 'column'
    },
    height: 'auto',
    width: '100%',
    justifyContent: {
      lg: 'space-around',
      xl: 'space-around',
      sm: 'center',
      xs: 'space-between'
    },
    pl: { xl: '0%', lg: '0%', sm: '0%', xs: '0%' },
    mt: { xl: 5, lg: 5 },
    mb: { xl: 8, lg: 8 }
  }}>
    {showCMonthAvgTable && <AverageMetersCurrentMonth />}
    {showCMonthFaultyTable && <FaultyMetersCurrentMonth />}
    {showCMonthUDueBill && <UpcomingDueBillCurrentMonth />}
  </Box>
)}


{(user?.role === 'Super Admin' || user?.role === 'Admin' || user?.role === 'Executive Engineer' || (user?.role === 'Junior Engineer' && user?.ward === 'Head Office')) && (
  <Box sx={{
    display: 'flex',
    flexDirection: {
      xl: 'row',
      lg: 'row',
      md: 'row',
      sm: 'column',
      xs: 'column'
    },
    width: '100%',
    justifyContent: {
      lg: 'space-around',
      xl: 'space-around',
      sm: 'center',
      xs: 'space-between'
    },
    pl: { xl: '0%', lg: '0%', sm: '0%', xs: '0%' },
  }}>
    {showPTwoMonthBeforePaidTable && <PaidBillpreviousTwoMonthBefore />}
    {showBeforeTwoMonthFaultyTable && <FaultyMetersBeforeTwoMonth />}
    {showOverdueBill &&  <OverdueBillsTable />}
  </Box>
)}


{(user?.role === 'Super Admin' || user?.role === 'Admin' || user?.role === 'Executive Engineer'|| (user?.role === 'Junior Engineer' && user?.ward === 'Head Office')) && (
  <InfoCard
  IconComponent={Person2OutlinedIcon}
//  backgroundColor="#fff9ed"
     backgroundColor="#fff"
    className="container-infocard"
    avatarColor="#FB404B"
    avatarIcon="PersonIcon"
    title="Total Tenders"
    count={meters.length} 
  />
)}
 </div>

    </div>
  );
};

export default Home;

