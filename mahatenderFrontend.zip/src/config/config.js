//export const baseUrl='https://lightbillsmanagement.onrender.com/api';

//export const baseUrl='http://localhost:2000/api';
// export const baseUrl='http://62.72.58.139:5000/api';
// -----------------------------------------------------------------------------
// export const baseUrl='https://lightbillbackend.onrender.com/api';
// export const billBaseUrl = 'https://lightbillbackend.onrender.com';

// export const baseUrl='https://lightbillapi.codifyinstitute.org/api';

 

export const baseUrl='http://localhost:5000/api';
export const billBaseUrl = 'http://localhost:5000';
export const fileBaseUrl = 'http://localhost:5000';


// export const baseUrl='https://lightbillbackend.saavi.co.in/api'
// export const billBaseUrl = 'https://lightbillbackend.saavi.co.in';