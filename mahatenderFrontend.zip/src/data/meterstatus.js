const meterstatus = [
    { "status": 'Normal' },
    { "status": 'Average' },
    { "status": 'Faulty' },
    { "status": 'Inactive' },
    ];

export default meterstatus;
