const rolesupervisors = [
    { "roleSupervisor": 'Super Admin'},
    { "roleSupervisor": 'Admin'},
    { "roleSupervisor": 'Junior Engineer'},
    {"roleSupervisor":"Executive Engineer"},
    {"roleSupervisor":"User"},
    {"roleSupervisor":"None"}
    ];
export default rolesupervisors;
