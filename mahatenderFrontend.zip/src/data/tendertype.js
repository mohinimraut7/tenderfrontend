const tendertype = [
    { "name": 'Open Tenders' },
    { "name": 'Limited' },
    { "name": 'Global Tenders' },
    ];

export default tendertype;
