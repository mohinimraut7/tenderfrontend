const tenderStatus = [
    { "name": 'To Be Opened Tenders' },
    { "name": 'Technical Bid Opening' },
    { "name": 'Technical Evaluation' },
    { "name": 'Financial Bid Opening' },
    { "name": 'Financial Evaluation' },
    { "name": 'AOC' },
    { "name": 'Retender' },
    { "name": 'Cancelled' },
    { "name": 'Concluded' },
    ];

export default tenderStatus;
