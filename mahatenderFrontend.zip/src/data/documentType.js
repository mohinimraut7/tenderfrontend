const documentType = [
    { "name": 'BOQ,Tender Documents' },
    { "name": 'Tender Documents,Other Document,BOQ' },
    { "name": 'Other Document,BOQ,Tender Documents' },
    { "name": 'Tender Documents' },
    { "name": 'Tender Documents,BOQ,Tender Documents,Additional Documents' },
    { "name": 'BOQ' },
    ];
export default documentType;
