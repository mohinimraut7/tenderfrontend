const phasetype = [
    { "name": '1 Phase' },
    { "name": '3 Phase' },
    ];

export default phasetype;
