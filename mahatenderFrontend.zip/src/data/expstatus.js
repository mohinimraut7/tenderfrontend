const expstatus = [
    { "name": 'Approved' },
    { "name": 'Rejected' },
    ];

export default expstatus;
