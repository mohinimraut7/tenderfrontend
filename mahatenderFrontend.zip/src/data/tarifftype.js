const tarifftype = [
    { "name": 'Domestic' },
    { "name": 'Commercial' },
    { "name": 'Industrial' },
    ];

export default tarifftype;
