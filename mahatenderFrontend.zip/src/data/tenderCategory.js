const tenderCategory = [
    { "name": 'Goods' },
    { "name": 'Services' },
    { "name": 'Works' },
    ];

export default tenderCategory;
