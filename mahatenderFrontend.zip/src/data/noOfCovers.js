const noOfCovers = [
    { "name": 1 },
    { "name": 2 },
    { "name": 3},
    { "name": 4}
    ];
export default noOfCovers;
