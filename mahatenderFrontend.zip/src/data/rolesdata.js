const rolesdata = [
    // { "rolename": 'Super Admin'},
    { "rolename": 'Admin'},
     { "rolename": 'Data Entry Operator'},
    // { "rolename": 'Junior Engineer','ward':'Ward-A'},
    // {"rolename":"Executive Engineer"},
    // {"rolename":"Lipik"},
    // {"rolename":"Accountant"},
    // {"rolename":"Assistant Municipal Commissioner"},
    // {"rolename":"Dy.Municipal Commissioner"},
    // {"rolename":"User"},
    // {"rolename":"None"}
    ];

export default rolesdata;
