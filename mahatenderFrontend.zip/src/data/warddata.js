const wardData = [
    { "ward": 'All',"wardid":1 },
    { "ward": 'Ward-A',"wardid":2 },
    { "ward": 'Ward-B',"wardid":3 },
    { "ward": 'Ward-C',"wardid":4 },
    {"ward": 'Ward-D',"wardid":5 },
    { "ward": 'Ward-E',"wardid":6 },
    { "ward": 'Ward-F',"wardid":7 },
    { "ward": 'Ward-G',"wardid":8 },
    { "ward": 'Ward-H',"wardid":9 },
    { "ward": 'Ward-I',"wardid":10 },
    { "ward": 'Head Office',"wardid":11 },
    ];

export default wardData;
