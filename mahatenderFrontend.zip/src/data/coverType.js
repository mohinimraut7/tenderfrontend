const coverType = [
    { "name": 'Fee/PreQual/Technical,Finance' },
    { "name": 'Finance' },
    ];

export default coverType;
