const formofcontract = [
    { "name": 'Piece-work' },
    { "name": 'Lump-sum' },
    { "name": 'Turn-key' },
    { "name": 'Fixed-rate' },
    { "name":'Item Rate' },
    { "name":'Tender cum Auction' },
    { "name":'QCBS' },
    { "name":'Percentage' },
    { "name":'Item Wise' },
    { "name":'PPP-Bot-Annuity' },
    { "name":'PPP-Bot-Toll' },
    { "name":'PPP-Bot-HAM' },
    { "name":'PPP-Bot-ToT' },
    { "name":'PPP-Bot-EOI' },
    { "name":'Empanelment' },
    ];

export default formofcontract;
