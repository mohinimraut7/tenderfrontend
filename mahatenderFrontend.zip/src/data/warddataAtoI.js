const wardData = [
    { "ward": 'Ward-A',"wardid":1},
    { "ward": 'Ward-B',"wardid":2},
    { "ward": 'Ward-C',"wardid":3},
    {"ward": 'Ward-D',"wardid":4},
    { "ward": 'Ward-E',"wardid":5},
    { "ward": 'Ward-F',"wardid":6},
    { "ward": 'Ward-G',"wardid":7},
    { "ward": 'Ward-H',"wardid":8},
    { "ward": 'Ward-I',"wardid":9},
    { "ward": 'All',"wardid":10},
    ];
export default wardData;
